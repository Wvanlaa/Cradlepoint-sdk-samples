#!/bin/bash
cppython ncxtunnelstatus.py