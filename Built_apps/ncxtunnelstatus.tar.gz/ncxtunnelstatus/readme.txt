Application Name
================
ncxtunnelstatus


Application Version
===================
0.9


NCOS Devices Supported
======================
ALL


External Requirements
=====================
Router being part of an NetCloud Exchange network.
Either self-hosted or NetCloud SASE

Application Purpose
===================
have a quick view if a site tunnel is up or down.
a tunnel with a status of "up" will show as "green", standy will show as "yellow"
all other states should show as "red"

Expected Output
===============
show the tunnel status in the Asset Identifier field in NCM
runs every 60 seconds


