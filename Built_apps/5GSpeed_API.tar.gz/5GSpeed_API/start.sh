#!/bin/bash
cppython 5GSpeed_API.py