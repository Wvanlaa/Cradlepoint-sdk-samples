Application Name
================
ports_status


Application Version
===================
1.45


NCOS Devices Supported
======================
ALL


External Requirements
=====================


Application Purpose
===================
This application will set the device description to visually show
the LAN/WAN/WWAN/Modem/IPSec Tunnel / IP Verify status
With IPVerify and VPN tunnel also the name is given as part of the output


Expected Output
===============
Sample Description:
WAN: 🟢 LAN: 🟢 ⚫️ ⚫️ ⚫️ ⚫️ 🟢 ⚫️ ⚫️ ⚫️ MDM: 🟡 MDM: ⚫️ IPV: 1 🟢 VPN:HQHub 🟢 
Description updated every 5 seconds
Log printed

