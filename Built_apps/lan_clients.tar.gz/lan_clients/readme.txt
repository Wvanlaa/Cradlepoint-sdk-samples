Application Name
================
lan_clients


Application Version
===================
1.0


NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
Get the lan client stats and put in desc to be sync'd to NCM


Expected Output
===============
LAN client stats in "Description" field of NCM

