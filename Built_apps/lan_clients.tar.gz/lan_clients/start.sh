#!/bin/bash
cppython lan_clients.py