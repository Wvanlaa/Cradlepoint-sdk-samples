#!/bin/bash
cppython ibr200lan_status.py