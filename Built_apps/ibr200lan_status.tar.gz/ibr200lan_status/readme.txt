Application Name
================
ports_status


Application Version
===================
1.10


NCOS Devices Supported
======================
ALL


External Requirements
=====================


Application Purpose
===================
This application will set the device asset ID to visually show
the LAN status
This variation on the ports_status SDK is mainly targeted towards IBR200 with e.g. a single industrial computer connected to the LAN port


Expected Output
===============
Asset Identifier updated
Log printed

